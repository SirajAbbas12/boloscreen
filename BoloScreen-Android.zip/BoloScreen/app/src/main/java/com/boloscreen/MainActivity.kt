package com.boloscreen

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.view.View
import android.widget.*
import java.io.File
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var voiceSp: Spinner
    private lateinit var rateBar: SeekBar
    private var voices = listOf<Voice>()
    private var ready = false

    private val langs = listOf(
        "Hindi" to "hi-IN", "English (India)" to "en-IN", "English (US)" to "en-US",
        "Bengali" to "bn-IN", "Marathi" to "mr-IN", "Tamil" to "ta-IN", "Telugu" to "te-IN",
        "Gujarati" to "gu-IN", "Kannada" to "kn-IN", "Malayalam" to "ml-IN", "Punjabi" to "pa-IN",
        "Urdu" to "ur-IN", "Odia" to "or-IN", "Assamese" to "as-IN", "Nepali" to "ne-NP"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun put(f: (SharedPreferences.Editor) -> Unit) {
        Prefs.p(this).edit().also(f).apply()
        ReaderService.inst?.let { it.applyVoice(); it.refreshButton() }
    }
    private fun label(t: String) = TextView(this).also {
        it.text = t; it.textSize = 16f; it.setTypeface(null, Typeface.BOLD)
        it.setPadding(0, dp(20), 0, dp(4)); root.addView(it)
    }
    private fun row(vararg items: Pair<String, () -> Unit>) {
        val r = LinearLayout(this)
        items.forEach { (t, a) ->
            r.addView(Button(this).also { b -> b.text = t; b.setOnClickListener { a() } },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(r)
    }
    private fun seek(min: Int, max: Int, cur: Int, on: (Int) -> Unit) = SeekBar(this).also { s ->
        s.max = max - min; s.progress = cur - min
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, user: Boolean) { if (user) on(p + min) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        root.addView(s)
    }
    private fun open(i: Intent) { try { startActivity(i) } catch (_: Exception) { Toast.makeText(this, "Ye phone mein available nahi", Toast.LENGTH_SHORT).show() } }
    private fun picker(on: (Int) -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(p: AdapterView<*>?, v: View?, i: Int, id: Long) = on(i)
        override fun onNothingSelected(p: AdapterView<*>?) {}
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this, this)
        val sv = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(36), dp(18), dp(36)) }
        sv.addView(root); setContentView(sv)

        root.addView(TextView(this).apply { text = "Bolo Screen"; textSize = 28f; setTypeface(null, Typeface.BOLD) })
        status = TextView(this).also { root.addView(it) }
        row("Permission do: Accessibility kholo" to { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })

        label("Bhasha")
        val ls = Spinner(this)
        ls.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, langs.map { it.first })
        ls.setSelection(langs.indexOfFirst { it.second == Prefs.s(this, "lang", "hi-IN") }.coerceAtLeast(0))
        ls.onItemSelectedListener = picker { i -> put { it.putString("lang", langs[i].second) }; refreshVoices() }
        root.addView(ls)

        label("Awaaz")
        voiceSp = Spinner(this).also { root.addView(it) }
        voiceSp.onItemSelectedListener = picker { i -> if (i < voices.size) put { it.putString("voice", voices[i].name) } }
        row("Aur awaazein download karo" to { open(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)) })
        row("Patli awaaz" to { put { it.putFloat("pitch", 1.25f) } },
            "Normal" to { put { it.putFloat("pitch", 1f) } },
            "Bhaari awaaz" to { put { it.putFloat("pitch", 0.8f) } })

        label("Bolne ki speed")
        fun setRate(v: Int) { rateBar.progress = v - 40; put { it.putFloat("rate", v / 100f) } }
        rateBar = seek(40, 200, (Prefs.f(this, "rate", 1f) * 100).toInt()) { v -> put { it.putFloat("rate", v / 100f) } }
        row("Bahut dheere" to { setRate(60) }, "Dheere" to { setRate(80) },
            "Normal" to { setRate(100) }, "Tez" to { setRate(140) })
        row("Awaaz suno (preview)" to { preview() })

        label("Floating button")
        row("Apni photo lagao" to { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1) },
            "Photo hatao" to { File(filesDir, "btn.png").delete(); ReaderService.inst?.refreshButton() })
        label("Size")
        seek(40, 100, Prefs.i(this, "size", 64)) { v -> put { it.putInt("size", v) } }
        label("Dhundhla / saaf (transparency)")
        seek(30, 100, Prefs.i(this, "alpha", 100)) { v -> put { it.putInt("alpha", v) } }
        root.addView(TextView(this).apply { text = "Tip: button ko ungli se kahin bhi khinch kar rakh sakte ho."; setPadding(0, dp(12), 0, 0) })
    }

    override fun onInit(s: Int) { ready = s == TextToSpeech.SUCCESS; refreshVoices() }

    private fun refreshVoices() {
        if (!ready) return
        val lang = Locale.forLanguageTag(Prefs.s(this, "lang", "hi-IN")).language
        voices = (tts.voices ?: emptySet()).filter { it.locale.language == lang }.sortedBy { it.name }
        val names = if (voices.isEmpty()) listOf("Is bhasha ki awaaz nahi mili. Neeche download karo")
        else voices.mapIndexed { i, v -> "Awaaz ${i + 1}" + if (v.isNetworkConnectionRequired) " (online)" else "" }
        voiceSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        voiceSp.setSelection(voices.indexOfFirst { it.name == Prefs.s(this, "voice", "") }.coerceAtLeast(0))
    }

    private fun preview() {
        if (!ready) return
        val loc = Locale.forLanguageTag(Prefs.s(this, "lang", "hi-IN"))
        tts.language = loc
        voices.firstOrNull { it.name == Prefs.s(this, "voice", "") }?.let { tts.voice = it }
        tts.setSpeechRate(Prefs.f(this, "rate", 1f)); tts.setPitch(Prefs.f(this, "pitch", 1f))
        val txt = if (loc.language == "hi") "नमस्ते, यह मेरी आवाज़ है। मैं आपकी स्क्रीन पढ़कर सुनाऊँगा।"
        else "Hello, this is my voice. I will read your screen aloud."
        tts.speak(txt, TextToSpeech.QUEUE_FLUSH, null, "p")
    }

    override fun onResume() {
        super.onResume()
        val on = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        status.text = if (on) "Chalu hai. Screen par floating button dikhega."
        else "Abhi band hai. Neeche button dabao, Bolo Screen chuno aur on karo."
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val u = data?.data ?: return
        if (requestCode != 1 || resultCode != RESULT_OK) return
        try {
            val bm = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, u)) { d, info, _ ->
                val m = 256f / maxOf(info.size.width, info.size.height)
                d.setTargetSize(maxOf(1, (info.size.width * m).toInt()), maxOf(1, (info.size.height * m).toInt()))
                d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
            File(filesDir, "btn.png").outputStream().use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
            ReaderService.inst?.refreshButton()
        } catch (_: Exception) { Toast.makeText(this, "Photo nahi khuli", Toast.LENGTH_SHORT).show() }
    }

    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
