package com.boloscreen

import android.accessibilityservice.AccessibilityService
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.speech.tts.TextToSpeech
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ImageView
import java.io.File
import java.util.Locale
import kotlin.math.abs

class ReaderService : AccessibilityService(), TextToSpeech.OnInitListener {
    companion object { var inst: ReaderService? = null }

    private var tts: TextToSpeech? = null
    private var ready = false
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var btn: ImageView? = null

    override fun onServiceConnected() {
        inst = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        addButton()
    }

    override fun onInit(status: Int) { ready = status == TextToSpeech.SUCCESS; applyVoice() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { tts?.stop() }

    override fun onDestroy() {
        inst = null
        btn?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        tts?.shutdown()
        super.onDestroy()
    }

    fun applyVoice() {
        val t = tts ?: return
        if (!ready) return
        val loc = Locale.forLanguageTag(Prefs.s(this, "lang", "hi-IN"))
        t.language = loc
        val name = Prefs.s(this, "voice", "")
        t.voices?.firstOrNull { it.name == name && it.locale.language == loc.language }?.let { t.voice = it }
        t.setSpeechRate(Prefs.f(this, "rate", 1f))
        t.setPitch(Prefs.f(this, "pitch", 1f))
    }

    fun refreshButton() {
        val b = btn ?: return
        val px = (Prefs.i(this, "size", 64) * resources.displayMetrics.density).toInt()
        lp.width = px; lp.height = px
        b.alpha = Prefs.i(this, "alpha", 100) / 100f
        val f = File(filesDir, "btn.png")
        if (f.exists()) b.setImageBitmap(BitmapFactory.decodeFile(f.path))
        else b.setImageResource(android.R.drawable.ic_media_play)
        wm.updateViewLayout(b, lp)
    }

    private fun addButton() {
        val b = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFF2A900.toInt()) }
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
        }
        lp = WindowManager.LayoutParams(
            0, 0, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = Prefs.i(this@ReaderService, "x", 40); y = Prefs.i(this@ReaderService, "y", 400) }
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 12 || abs(my) > 12) moved = true
                    if (moved) { lp.x = sx + mx; lp.y = sy + my; wm.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP -> if (moved) Prefs.p(this).edit().putInt("x", lp.x).putInt("y", lp.y).apply() else toggle()
            }
            true
        }
        btn = b
        wm.addView(b, lp)
        refreshButton()
    }

    private fun toggle() {
        val t = tts ?: return
        if (t.isSpeaking) { t.stop(); return }
        val sb = StringBuilder()
        rootInActiveWindow?.let { collect(it, sb) }
        sb.toString().chunked(3500).forEachIndexed { i, c ->
            t.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "r$i")
        }
    }

    private fun collect(n: AccessibilityNodeInfo, sb: StringBuilder) {
        if (!n.isVisibleToUser) return
        val s = n.text ?: n.contentDescription
        if (!s.isNullOrBlank()) sb.append(s).append(". ")
        for (i in 0 until n.childCount) n.getChild(i)?.let { collect(it, sb) }
    }
}
