package com.boloscreen

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.util.Locale
import kotlin.math.abs

class ReaderService : AccessibilityService(), TextToSpeech.OnInitListener {
    companion object { var inst: ReaderService? = null }
    class Item(val text: String, val r: Rect)

    private var tts: TextToSpeech? = null
    private var ready = false
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var btn: ImageView? = null
    private var layer: Layer? = null
    private var panel: View? = null
    private var playBtn: ImageView? = null
    private var items = listOf<Item>()
    private var idx = 0
    private var endIdx = 0
    private var playing = false
    private var paused = false
    private val main = Handler(Looper.getMainLooper())
    private var hidden = false
    private var rootNull = false
    private var ttsMsg: TextToSpeech? = null
    private var msgReady = false
    private var hideLeft = true
    private val hideRunner = Runnable { hideToEdge() }
    private val idleRunner = Runnable { if (!playing && panel != null) collapse() }
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun alphaUser() = Prefs.i(this, "alpha", 100) / 100f
    private fun moveX(to: Int) {
        val b = btn ?: return
        android.animation.ValueAnimator.ofInt(lp.x, to).apply {
            duration = 180
            addUpdateListener { try { lp.x = it.animatedValue as Int; wm.updateViewLayout(b, lp) } catch (_: Exception) {} }
            start()
        }
    }
    private fun snapToEdge() {
        hideLeft = lp.x + lp.width / 2 < screenW() / 2
        lp.y = lp.y.coerceIn(dp(24), maxOf(dp(24), resources.displayMetrics.heightPixels - lp.height - dp(48)))
        val tx = if (hideLeft) 0 else screenW() - lp.width
        moveX(tx)
        Prefs.p(this).edit().putInt("x", tx).putInt("y", lp.y).apply()
        scheduleHide()
    }
    private fun scheduleHide() {
        main.removeCallbacks(hideRunner)
        if (Prefs.p(this).getBoolean("autohide", true) && panel == null) main.postDelayed(hideRunner, 3000)
    }
    private fun styleButton() {
        val b = btn ?: return
        val px = dp(Prefs.i(this, "size", 64))
        lp.height = px
        lp.width = if (hidden) dp(18) else px
        (b.background as? GradientDrawable)?.cornerRadius = if (hidden) dp(9).toFloat() else px * 0.28f
        b.imageAlpha = if (hidden) 0 else 255
        b.alpha = alphaUser() * (if (hidden) 0.6f else 1f)
    }
    private fun hideToEdge() {
        val b = btn ?: return
        if (panel != null || hidden) return
        hidden = true
        styleButton()
        lp.x = if (hideLeft) 0 else screenW() - lp.width
        try { wm.updateViewLayout(b, lp) } catch (_: Exception) {}
    }
    private fun revealNow() {
        val b = btn ?: return
        hidden = false
        styleButton()
        lp.x = if (hideLeft) 0 else screenW() - lp.width
        try { wm.updateViewLayout(b, lp) } catch (_: Exception) {}
    }

    override fun onServiceConnected() {
        inst = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        ttsMsg = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) { ttsMsg?.language = Locale("en", "IN"); msgReady = true }
        }
        addButton()
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {
                val k = id?.drop(1)?.toIntOrNull() ?: return
                main.post { idx = k; layer?.hi = items.getOrNull(k)?.r; layer?.invalidate() }
            }
            override fun onDone(id: String?) {
                val k = id?.drop(1)?.toIntOrNull() ?: return
                if (k == endIdx) main.post { playing = false; layer?.hi = null; layer?.invalidate(); updatePlay(); main.postDelayed(idleRunner, 8000) }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) {}
        })
        applyVoice()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e?.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) adjustForIme()
    }

    private fun adjustForIme() {
        val b = btn ?: return
        if (panel != null) return
        val r = Rect()
        val ime = windows.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }
        ime?.getBoundsInScreen(r)
        val saved = Prefs.i(this, "y", 400)
        val limit = if (ime != null) r.top - lp.height - dp(8) else saved
        val ny = minOf(saved, limit).coerceAtLeast(dp(24))
        if (ny != lp.y) { lp.y = ny; try { wm.updateViewLayout(b, lp) } catch (_: Exception) {} }
    }
    override fun onInterrupt() { tts?.stop() }

    override fun onDestroy() {
        inst = null
        collapse()
        btn?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        tts?.shutdown()
        ttsMsg?.shutdown()
        super.onDestroy()
    }

    fun applyVoice() {
        val t = tts ?: return
        if (!ready) return
        val loc = Locale.forLanguageTag(Prefs.s(this, "lang", "hi-IN"))
        t.language = loc
        val name = Prefs.s(this, "voice", "")
        t.voices?.firstOrNull { it.name == name && it.locale.language == loc.language }?.let { t.voice = it }
        t.setSpeechRate(Prefs.f(this, "rate", 1f))
        t.setPitch(Prefs.f(this, "pitch", 1f))
    }

    fun refreshButton() {
        val b = btn ?: return
        styleButton()
        if (!hidden) lp.x = if (hideLeft) 0 else screenW() - lp.width
        val f = File(filesDir, "btn.png")
        if (f.exists()) { b.setPadding(0, 0, 0, 0); b.imageTintList = null; b.setImageBitmap(BitmapFactory.decodeFile(f.path)) }
        else { b.setPadding(dp(16), dp(16), dp(16), dp(16)); b.imageTintList = ColorStateList.valueOf(0xFF14233A.toInt()); b.setImageResource(R.drawable.ic_play) }
        if (panel == null) b.visibility = if (Prefs.p(this).getBoolean("show", true)) View.VISIBLE else View.GONE
        wm.updateViewLayout(b, lp)
        if (hidden && !Prefs.p(this).getBoolean("autohide", true)) revealNow() else scheduleHide()
    }

    private fun addButton() {
        val b = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Bolo Screen"
            background = GradientDrawable().apply { setColor(0xFFF2A900.toInt()); setStroke(dp(2), 0xCC000000.toInt()) }
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
        }
        lp = WindowManager.LayoutParams(
            0, 0, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = Prefs.i(this@ReaderService, "x", 40); y = Prefs.i(this@ReaderService, "y", 400) }
        hideLeft = lp.x + dp(32) < screenW() / 2
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { main.removeCallbacks(hideRunner); if (hidden) revealNow(); dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 12 || abs(my) > 12) moved = true
                    if (moved) { lp.x = sx + mx; lp.y = sy + my; wm.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP -> if (moved) snapToEdge() else expand()
            }
            true
        }
        btn = b
        wm.addView(b, lp)
        refreshButton()
        snapToEdge()
    }

    // ---- control panel + highlight layer ----
    private fun expand() {
        if (panel != null) return
        items = scan()
        val mp = WindowManager.LayoutParams.MATCH_PARENT
        val l = Layer(this)
        wm.addView(l, WindowManager.LayoutParams(
            mp, mp, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT))
        layer = l
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply { cornerRadius = dp(28).toFloat(); setColor(0xF014233A.toInt()) }
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        fun key(res: Int, desc: String, color: Int = Color.WHITE, a: () -> Unit): ImageView {
            val v = ImageView(this).apply {
                setImageResource(res); imageTintList = ColorStateList.valueOf(color)
                setPadding(dp(12), dp(12), dp(12), dp(12)); contentDescription = desc
                isClickable = true; setOnClickListener { main.removeCallbacks(idleRunner); a(); if (!playing) main.postDelayed(idleRunner, 8000) }
            }
            bar.addView(v, LinearLayout.LayoutParams(dp(48), dp(48)))
            return v
        }
        key(R.drawable.ic_settings, "Settings") { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        key(R.drawable.ic_prev, "Pichla") { if (items.isNotEmpty()) speak(maxOf(idx - 1, 0), items.lastIndex) }
        playBtn = key(R.drawable.ic_play, "Play ya pause") { playPause() }
        key(R.drawable.ic_next, "Agla") { if (items.isNotEmpty()) speak(minOf(idx + 1, items.lastIndex), items.lastIndex) }
        key(R.drawable.ic_stop, "Roko", 0xFFFF8A80.toInt()) { tts?.stop(); playing = false; paused = false; collapse() }
        key(R.drawable.ic_chevron_left, "Chhupao") { collapse() }
        val pl = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = lp.x.coerceIn(0, maxOf(0, resources.displayMetrics.widthPixels - dp(300)))
            y = lp.y
        }
        wm.addView(bar, pl)
        panel = bar
        btn?.visibility = View.GONE
        updatePlay()
        main.postDelayed(idleRunner, 8000)
    }

    private fun collapse() {
        main.removeCallbacks(idleRunner)
        layer?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        layer = null; panel = null; playBtn = null
        refreshButton()
    }

    private fun updatePlay() { playBtn?.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play) }

    private fun playPause() {
        if (playing) { tts?.stop(); playing = false; paused = true; updatePlay(); return }
        if (paused && items.isNotEmpty()) { speak(idx, endIdx); return }
        items = scan()
        layer?.hi = null
        if (items.isNotEmpty()) speak(0, items.lastIndex) else say(rootNull)
    }

    private fun speak(from: Int, to: Int) {
        val t = tts ?: return
        if (items.isEmpty() || from !in items.indices) return
        main.removeCallbacks(idleRunner)
        idx = from; endIdx = to.coerceIn(from, items.lastIndex)
        t.stop()
        for (k in from..endIdx) t.speak(items[k].text, if (k == from) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "i$k")
        playing = true; paused = false
        updatePlay()
    }

    private fun say(blocked: Boolean) {
        tts?.stop()
        if (msgReady) ttsMsg?.speak(if (blocked) "This screen cannot be read." else "No text at this location.", TextToSpeech.QUEUE_FLUSH, null, "msg")
        playing = false; paused = false; layer?.hi = null; layer?.invalidate(); updatePlay()
    }

    private fun pickPoint(x: Int, y: Int) {
        items = scan()
        val i = items.withIndex().filter { it.value.r.contains(x, y) }
            .minByOrNull { it.value.r.width() * it.value.r.height() }?.index
        if (i != null) speak(i, i) else say(rootNull)
    }

    private fun pickRect(r: Rect) {
        items = scan()
        val ix = items.withIndex().filter { Rect.intersects(it.value.r, r) }.map { it.index }
        if (ix.isNotEmpty()) speak(ix.min(), ix.max()) else say(rootNull)
    }

    private fun scan(): List<Item> {
        val out = mutableListOf<Item>()
        val r = rootInActiveWindow
        rootNull = r == null
        r?.let { collect(it, out) }
        return out.sortedWith(compareBy<Item>({ it.r.top / 24 }, { it.r.left }))
    }

    private fun collect(n: AccessibilityNodeInfo, out: MutableList<Item>) {
        if (!n.isVisibleToUser) return
        val s = (n.text ?: n.contentDescription)?.toString()?.trim()
        if (!s.isNullOrEmpty()) {
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) out.add(Item(s.take(3900), r))
        }
        for (i in 0 until n.childCount) n.getChild(i)?.let { collect(it, out) }
    }

    inner class Layer(c: Context) : View(c) {
        var hi: Rect? = null
        var sel: Rect? = null
        private val stroke = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 6f; color = 0xFF2ECC40.toInt() }
        private val fill = Paint().apply { style = Paint.Style.FILL; color = 0x332ECC40 }
        private var sx = 0f; private var sy = 0f; private var drag = false

        override fun onDraw(c: Canvas) {
            val l = IntArray(2); getLocationOnScreen(l)
            c.translate(-l[0].toFloat(), -l[1].toFloat())
            hi?.let { c.drawRect(it, fill); c.drawRect(it, stroke) }
            sel?.let { c.drawRect(it, stroke) }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; drag = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > 25 || abs(e.rawY - sy) > 25) drag = true
                    if (drag) {
                        sel = Rect(minOf(sx, e.rawX).toInt(), minOf(sy, e.rawY).toInt(), maxOf(sx, e.rawX).toInt(), maxOf(sy, e.rawY).toInt())
                        invalidate()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    val s = sel
                    if (drag && s != null) pickRect(s) else pickPoint(e.rawX.toInt(), e.rawY.toInt())
                    sel = null; invalidate()
                }
            }
            return true
        }
    }
}
