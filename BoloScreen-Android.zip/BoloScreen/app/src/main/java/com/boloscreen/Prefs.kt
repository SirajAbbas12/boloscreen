package com.boloscreen

import android.content.Context

object Prefs {
    fun p(c: Context) = c.getSharedPreferences("bs", 0)
    fun s(c: Context, k: String, d: String) = p(c).getString(k, d) ?: d
    fun f(c: Context, k: String, d: Float) = p(c).getFloat(k, d)
    fun i(c: Context, k: String, d: Int) = p(c).getInt(k, d)
}
